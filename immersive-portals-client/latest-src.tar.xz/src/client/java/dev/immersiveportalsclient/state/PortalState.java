package dev.immersiveportalsclient.state;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.core.BlockPos;

public final class PortalState {
    public enum Kind { NONE, NETHER, END }

    private static Kind nearbyKind = Kind.NONE;
    private static float immersion;
    private static int levelChangeFlashTicks;
    private static ResourceKey<Level> dimension;

    // Kept across the short vanilla level swap so PortalMemory can associate the real arrival
    // with the opening the player actually entered.
    private static List<PortalFrame> visiblePortals = List.of();
    private static int discoveryCooldown;
    private static PortalFrame lastObservedPortal;
    private static PortalMemory.SceneSnapshot lastObservedScene;
    private static PortalFrame lastClosePortal;
    private static PortalMemory.SceneSnapshot lastSourceScene;
    private static int closePortalGraceTicks;
    private static int closeSceneRefreshCooldown;

    private PortalState() { }

    public static void tick(Minecraft client) {
        if (client.player == null || client.level == null) {
            nearbyKind = Kind.NONE;
            immersion = Math.max(0.0f, immersion - 0.12f);
            levelChangeFlashTicks = 0;
            return;
        }

        dimension = client.level.dimension();
        nearbyKind = detectPortal(client);

        if (discoveryCooldown-- <= 0) {
            visiblePortals = PortalScanner.scan(client.level, client.player.position(), 12, 12);
            discoveryCooldown = 5;
        }

        PortalFrame observed = nearestVisible(client.player.position());
        if (observed != null) {
            if (lastObservedPortal == null || !lastObservedPortal.sameOpening(observed)) {
                // First sight: cache a 3D neighbourhood around the opening immediately.
                lastObservedPortal = observed;
                lastObservedScene = PortalMemory.rememberFirstSeen(client.level, observed, client.player.getYRot());
            }

            if (observed.distanceToSqr(client.player.position()) <= 12.25) {
                lastClosePortal = observed;
                // Keep a recent source-side cache while the player is actually entering the portal.
                // This costs one local scan per second at most and avoids learning a stale scene if
                // blocks changed since the portal was first discovered.
                if (lastSourceScene == null || closeSceneRefreshCooldown-- <= 0) {
                    lastSourceScene = PortalMemory.refreshObserved(client.level, observed, client.player.getYRot());
                    closeSceneRefreshCooldown = 20;
                }
                closePortalGraceTicks = 16;
            } else if (closePortalGraceTicks > 0) {
                closePortalGraceTicks--;
            }
        } else if (closePortalGraceTicks > 0) {
            closePortalGraceTicks--;
        } else {
            lastClosePortal = null;
            lastSourceScene = null;
            closeSceneRefreshCooldown = 0;
        }

        float target = nearbyKind == Kind.NONE ? 0.0f : 1.0f;
        float speed = target > immersion ? 0.16f : 0.08f;
        immersion += (target - immersion) * speed;

        if (levelChangeFlashTicks > 0) {
            levelChangeFlashTicks--;
        }
    }

    public static void onLevelChanged(ResourceKey<Level> newDimension) {
        dimension = newDimension;
        visiblePortals = List.of();
        discoveryCooldown = 0;
        levelChangeFlashTicks = 12;
        immersion = Math.max(immersion, 0.65f);
    }

    private static Kind detectPortal(Minecraft client) {
        BlockPos origin = client.player.blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        for (int y = -1; y <= 2; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    cursor.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    var state = client.level.getBlockState(cursor);
                    if (state.is(Blocks.NETHER_PORTAL)) return Kind.NETHER;
                    if (state.is(Blocks.END_PORTAL)) return Kind.END;
                }
            }
        }
        return Kind.NONE;
    }


    private static PortalFrame nearestVisible(net.minecraft.world.phys.Vec3 point) {
        PortalFrame best = null;
        double bestDistance = Double.MAX_VALUE;
        for (PortalFrame frame : visiblePortals) {
            double distance = frame.distanceToSqr(point);
            if (distance < bestDistance) {
                best = frame;
                bestDistance = distance;
            }
        }
        return best;
    }

    public static Kind nearbyKind() {
        return nearbyKind;
    }

    public static float visualStrength() {
        float flash = levelChangeFlashTicks / 12.0f;
        return Math.min(1.0f, Math.max(immersion, flash));
    }

    public static boolean isTransitioning() {
        return levelChangeFlashTicks > 0;
    }

    public static ResourceKey<Level> currentDimension() {
        return dimension;
    }

    public static List<PortalFrame> visiblePortals() {
        return visiblePortals;
    }

    public static PortalFrame lastClosePortal() {
        return lastClosePortal;
    }

    public static PortalMemory.SceneSnapshot lastSourceScene() {
        return lastSourceScene;
    }

    public static ResourceKey<Level> visualTargetDimension(Kind kind) {
        if (kind == Kind.END) {
            return Level.END.equals(dimension) ? Level.OVERWORLD : Level.END;
        }
        if (kind == Kind.NETHER) {
            return Level.NETHER.equals(dimension) ? Level.OVERWORLD : Level.NETHER;
        }
        return dimension;
    }
}
