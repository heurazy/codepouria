package dev.immersiveportalsclient.state;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Finds connected vanilla Nether/End portal openings in the currently loaded client level. */
public final class PortalScanner {
    private static final int MAX_COMPONENT_BLOCKS = 256;

    private PortalScanner() { }

    public static List<PortalFrame> scan(ClientLevel level, Vec3 around, int radius, int maxFrames) {
        BlockPos center = BlockPos.containing(around.x, around.y, around.z);
        Set<BlockPos> visited = new HashSet<>();
        ArrayList<PortalFrame> result = new ArrayList<>();

        for (int y = -radius; y <= radius && result.size() < maxFrames; y++) {
            for (int x = -radius; x <= radius && result.size() < maxFrames; x++) {
                for (int z = -radius; z <= radius && result.size() < maxFrames; z++) {
                    BlockPos pos = new BlockPos(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (visited.contains(pos)) continue;

                    PortalState.Kind kind = kindAt(level, pos);
                    if (kind == PortalState.Kind.NONE) continue;

                    PortalFrame frame = collectComponent(level, pos, kind, visited);
                    if (frame != null) result.add(frame);
                }
            }
        }

        return List.copyOf(result);
    }

    public static PortalFrame nearest(ClientLevel level, Vec3 around, int radius) {
        PortalFrame best = null;
        double bestDistance = Double.MAX_VALUE;
        for (PortalFrame frame : scan(level, around, radius, 12)) {
            double distance = frame.distanceToSqr(around);
            if (distance < bestDistance) {
                best = frame;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static PortalFrame collectComponent(
        ClientLevel level,
        BlockPos start,
        PortalState.Kind kind,
        Set<BlockPos> visited
    ) {
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(start);
        visited.add(start);

        int minX = start.getX();
        int minY = start.getY();
        int minZ = start.getZ();
        int maxX = minX;
        int maxY = minY;
        int maxZ = minZ;
        int count = 0;

        while (!queue.isEmpty() && count < MAX_COMPONENT_BLOCKS) {
            BlockPos pos = queue.removeFirst();
            count++;

            minX = Math.min(minX, pos.getX());
            minY = Math.min(minY, pos.getY());
            minZ = Math.min(minZ, pos.getZ());
            maxX = Math.max(maxX, pos.getX());
            maxY = Math.max(maxY, pos.getY());
            maxZ = Math.max(maxZ, pos.getZ());

            addIfPortal(level, pos.offset(1, 0, 0), kind, visited, queue);
            addIfPortal(level, pos.offset(-1, 0, 0), kind, visited, queue);
            addIfPortal(level, pos.offset(0, 1, 0), kind, visited, queue);
            addIfPortal(level, pos.offset(0, -1, 0), kind, visited, queue);
            addIfPortal(level, pos.offset(0, 0, 1), kind, visited, queue);
            addIfPortal(level, pos.offset(0, 0, -1), kind, visited, queue);
        }

        PortalFrame.Plane plane;
        if (kind == PortalState.Kind.END) {
            plane = PortalFrame.Plane.HORIZONTAL;
        } else {
            int spanX = maxX - minX;
            int spanZ = maxZ - minZ;
            if (spanX == 0 && spanZ == 0) {
                boolean eastWest = kindAt(level, start.offset(1, 0, 0)) == kind
                    || kindAt(level, start.offset(-1, 0, 0)) == kind;
                plane = eastWest ? PortalFrame.Plane.X : PortalFrame.Plane.Z;
            } else {
                plane = spanX >= spanZ ? PortalFrame.Plane.X : PortalFrame.Plane.Z;
            }
        }

        return new PortalFrame(
            level.dimension(), kind, plane,
            minX, minY, minZ,
            maxX, maxY, maxZ
        );
    }

    private static void addIfPortal(
        ClientLevel level,
        BlockPos pos,
        PortalState.Kind kind,
        Set<BlockPos> visited,
        ArrayDeque<BlockPos> queue
    ) {
        if (visited.contains(pos)) return;
        if (kindAt(level, pos) != kind) return;
        visited.add(pos);
        queue.addLast(pos);
    }

    private static PortalState.Kind kindAt(ClientLevel level, BlockPos pos) {
        var state = level.getBlockState(pos);
        if (state.is(Blocks.NETHER_PORTAL)) return PortalState.Kind.NETHER;
        if (state.is(Blocks.END_PORTAL)) return PortalState.Kind.END;
        return PortalState.Kind.NONE;
    }
}
