package dev.immersiveportalsclient.state;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import dev.immersiveportalsclient.ImmersivePortalsClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Learns vanilla portal destinations strictly from places the client has actually visited.
 * Nothing is requested from the server and no custom packet is sent.
 */
public final class PortalMemory {
    public record BlockSample(short dx, short dy, short dz, BlockState state, int packedLight) { }

    /**
     * A compact 3D snapshot around a portal/arrival point. BlockState data lets the renderer
     * reconstruct actual Minecraft block models with parallax instead of storing a flat picture.
     */
    public record SceneSnapshot(
        ResourceKey<Level> dimension,
        Vec3 origin,
        float yaw,
        List<BlockSample> blocks,
        long capturedGameTime
    ) { }

    public record LearnedDestination(
        PortalFrame source,
        PortalFrame destinationPortal,
        SceneSnapshot destinationScene
    ) { }

    private static final int CAPTURE_XZ = 12;
    private static final int CAPTURE_DOWN = 6;
    private static final int CAPTURE_UP = 10;
    private static final int ARRIVAL_SEARCH_TICKS = 100;
    private static final int MAX_OBSERVED_SCENES = 12;
    private static final int MIN_REAL_PORTAL_ARRIVAL_TICKS = 5;
    private static final double TRAVERSAL_CANDIDATE_DISTANCE_SQR = 12.25; // 3.5 blocks

    private static final Map<PortalFrame, LearnedDestination> learned = new HashMap<>();
    /**
     * First-sight/source-side snapshots. Kept separately from learned destinations: merely seeing a
     * portal never activates the immersive renderer. A destination becomes learned only after a real
     * vanilla dimension change. Access-order keeps memory bounded on long multiplayer sessions.
     */
    private static final LinkedHashMap<PortalFrame, SceneSnapshot> observedScenes =
        new LinkedHashMap<>(16, 0.75f, true);

    private static PortalFrame traversalCandidate;
    private static PortalFrame pendingSource;
    private static SceneSnapshot pendingSourceScene;
    private static ResourceKey<Level> previousDimension;
    private static int arrivalTicks;
    private static PortalFrame arrivalPortalCandidate;
    private static boolean pendingArrivalCapture;

    private PortalMemory() { }

    public static void tick(Minecraft client) {
        if (client.player == null || client.level == null) return;

        ClientLevel level = client.level;
        Vec3 playerPos = client.player.position();
        PortalFrame nearest = PortalState.lastClosePortal();

        if (nearest != null && nearest.dimension().equals(level.dimension())
            && nearest.distanceToSqr(playerPos) <= TRAVERSAL_CANDIDATE_DISTANCE_SQR) {
            traversalCandidate = nearest;
        } else {
            traversalCandidate = null;
        }

        if (!pendingArrivalCapture) return;

        arrivalTicks++;
        if (arrivalTicks == 1 || arrivalTicks % 4 == 0) {
            arrivalPortalCandidate = PortalScanner.nearest(level, playerPos, 10);
        }
        PortalFrame destinationPortal = arrivalPortalCandidate;

        // Give vanilla a few client ticks to finish positioning the player/chunks before capturing.
        // Nether normally has a real destination portal. End entry normally does not, so End uses
        // the actual arrival viewpoint as a virtual destination after the scene settles briefly.
        boolean canFinalize = arrivalTicks >= MIN_REAL_PORTAL_ARRIVAL_TICKS
            && destinationPortal != null
            && destinationPortal.kind() == pendingSource.kind();
        boolean endVirtualDestination = pendingSource.kind() == PortalState.Kind.END && arrivalTicks >= 10;
        boolean timedFallback = arrivalTicks >= ARRIVAL_SEARCH_TICKS;

        if (canFinalize || endVirtualDestination || timedFallback) {
            Vec3 captureOrigin = canFinalize ? destinationPortal.center() : playerPos;
            SceneSnapshot scene = capture(level, captureOrigin, client.player.getYRot());
            learn(pendingSource, canFinalize ? destinationPortal : null, scene);

            // When both sides are actual vanilla portal openings, the first traversal teaches both
            // directions. The reverse scene is the fresh source-side snapshot kept before the swap.
            if (canFinalize && pendingSourceScene != null) {
                learned.put(destinationPortal, new LearnedDestination(destinationPortal, pendingSource, pendingSourceScene));
            }

            ImmersivePortalsClient.LOGGER.info(
                "Learned client-only {} portal destination: {} cached blocks{}",
                pendingSource.kind(),
                scene.blocks().size(),
                canFinalize ? " (paired vanilla openings)" : " (virtual arrival)"
            );

            pendingArrivalCapture = false;
            pendingSource = null;
            pendingSourceScene = null;
            arrivalTicks = 0;
            arrivalPortalCandidate = null;
        }
    }

    /** Called by the Fabric level-change event after vanilla/server has moved the player. */
    public static void onLevelChanged(Minecraft client, ResourceKey<Level> newDimension) {
        previousDimension = PortalState.currentDimension();
        PortalFrame candidate = traversalCandidate != null ? traversalCandidate : PortalState.lastClosePortal();

        if (candidate != null && previousDimension != null && !previousDimension.equals(newDimension)) {
            pendingSource = candidate;
            pendingSourceScene = PortalState.lastSourceScene();
            if (pendingSourceScene == null) {
                pendingSourceScene = observedScenes.get(candidate);
            }
            pendingArrivalCapture = true;
            arrivalTicks = 0;
            arrivalPortalCandidate = null;
        } else {
            pendingSource = null;
            pendingSourceScene = null;
            pendingArrivalCapture = false;
            arrivalTicks = 0;
            arrivalPortalCandidate = null;
        }
    }

    public static boolean isLearned(PortalFrame frame) {
        return frame != null && learned.containsKey(frame);
    }

    public static LearnedDestination destinationFor(PortalFrame frame) {
        return learned.get(frame);
    }

    public static int learnedPortalCount() {
        return learned.size();
    }

    /** Capture once when a portal opening is first discovered. This alone does not activate it. */
    public static SceneSnapshot rememberFirstSeen(ClientLevel level, PortalFrame frame, float yaw) {
        SceneSnapshot existing = observedScenes.get(frame);
        if (existing != null) return existing;

        SceneSnapshot snapshot = capture(level, frame.center(), yaw);
        putObserved(frame, snapshot);
        return snapshot;
    }

    /** Refresh the source side immediately before traversal so changed blocks are not stale. */
    public static SceneSnapshot refreshObserved(ClientLevel level, PortalFrame frame, float yaw) {
        SceneSnapshot snapshot = capture(level, frame.center(), yaw);
        putObserved(frame, snapshot);
        return snapshot;
    }

    private static void putObserved(PortalFrame frame, SceneSnapshot snapshot) {
        observedScenes.put(frame, snapshot);
        while (observedScenes.size() > MAX_OBSERVED_SCENES) {
            PortalFrame oldest = observedScenes.keySet().iterator().next();
            observedScenes.remove(oldest);
        }
    }

    private static void learn(PortalFrame source, PortalFrame destinationPortal, SceneSnapshot scene) {
        learned.put(source, new LearnedDestination(source, destinationPortal, scene));
    }

    public static SceneSnapshot capture(ClientLevel level, Vec3 origin, float yaw) {
        BlockPos center = BlockPos.containing(origin.x, origin.y, origin.z);
        ArrayList<BlockSample> blocks = new ArrayList<>();

        for (int dy = -CAPTURE_DOWN; dy <= CAPTURE_UP; dy++) {
            for (int dx = -CAPTURE_XZ; dx <= CAPTURE_XZ; dx++) {
                for (int dz = -CAPTURE_XZ; dz <= CAPTURE_XZ; dz++) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir()) continue;

                    int blockLight = level.getBrightness(LightLayer.BLOCK, pos);
                    int skyLight = level.getBrightness(LightLayer.SKY, pos);
                    int packedLight = LightCoordsUtil.pack(blockLight, skyLight);
                    blocks.add(new BlockSample((short) dx, (short) dy, (short) dz, state, packedLight));
                }
            }
        }

        return new SceneSnapshot(level.dimension(), origin, yaw, List.copyOf(blocks), level.getGameTime());
    }
}
