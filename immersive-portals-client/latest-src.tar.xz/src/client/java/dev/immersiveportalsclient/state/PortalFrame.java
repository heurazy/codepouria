package dev.immersiveportalsclient.state;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Immutable description of one vanilla portal opening as observed by the client.
 * It contains only data that the server already sent through normal chunk updates.
 */
public record PortalFrame(
    ResourceKey<Level> dimension,
    PortalState.Kind kind,
    Plane plane,
    int minX,
    int minY,
    int minZ,
    int maxX,
    int maxY,
    int maxZ
) {
    public enum Plane { X, Z, HORIZONTAL }

    public Vec3 center() {
        return new Vec3(
            (minX + maxX + 1) * 0.5,
            (minY + maxY + 1) * 0.5,
            (minZ + maxZ + 1) * 0.5
        );
    }

    public double distanceToSqr(Vec3 point) {
        Vec3 center = center();
        double dx = center.x - point.x;
        double dy = center.y - point.y;
        double dz = center.z - point.z;
        return dx * dx + dy * dy + dz * dz;
    }

    public boolean sameOpening(PortalFrame other) {
        return other != null
            && dimension.equals(other.dimension)
            && kind == other.kind
            && plane == other.plane
            && minX == other.minX
            && minY == other.minY
            && minZ == other.minZ
            && maxX == other.maxX
            && maxY == other.maxY
            && maxZ == other.maxZ;
    }
}
