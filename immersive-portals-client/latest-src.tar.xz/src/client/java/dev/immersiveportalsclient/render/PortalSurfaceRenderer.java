package dev.immersiveportalsclient.render;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import dev.immersiveportalsclient.state.PortalFrame;
import dev.immersiveportalsclient.state.PortalMemory;
import dev.immersiveportalsclient.state.PortalState;
import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Renders a learned destination as a full-scale cached world behind the vanilla portal opening.
 *
 * <p>This intentionally follows the visual idea used by upstream Immersive Portals: the portal is
 * a window, not a texture pasted on each portal block. Upstream can render a second live ClientLevel
 * into a framebuffer because its server supplies remote chunks. This client-only port cannot ask an
 * unmodded server for those chunks, so the remote scene comes from PortalMemory after a real vanilla
 * traversal.</p>
 *
 * <p>Unknown portals are untouched. Once learned, destination blocks are placed at 1:1 scale behind
 * the opening and rejected unless the camera-to-block ray intersects the portal rectangle. This is
 * the important difference from the old compressed voxel preview that caused the pixel-soup look.</p>
 */
public final class PortalSurfaceRenderer {
    private static final Matrix4fc IDENTITY_MATRIX = new Matrix4f();
    private static final int MAX_SURFACE_SAMPLES_PER_PORTAL = 1100;
    private static final double INSET = 0.045;
    private static final double APERTURE_MARGIN = 0.32;
    private static final double PORTAL_EPSILON = 0.10;
    private static final double BACKING_THICKNESS = 0.025;
    private static final double BACKING_DEPTH = 13.6;

    private record PreparedSample(
        short dx,
        short dy,
        short dz,
        int packedLight,
        BlockModelRenderState model
    ) { }

    private record LearnedFrame(
        PortalFrame frame,
        PortalFrame destinationPortal,
        PortalMemory.SceneSnapshot scene,
        List<PreparedSample> samples
    ) { }

    private record LocalPoint(double u, double v, double n) { }

    /** Block states are immutable/canonical, so their extracted model meshes can be reused. */
    private static final Map<BlockState, BlockModelRenderState> MODEL_CACHE = new HashMap<>();
    private static List<LearnedFrame> learnedFrames = List.of();

    private PortalSurfaceRenderer() { }

    public static void register() {
        LevelExtractionEvents.END_EXTRACTION.register(PortalSurfaceRenderer::extract);
        LevelRenderEvents.COLLECT_SUBMITS.register(PortalSurfaceRenderer::collectSubmits);
    }

    private static void extract(LevelExtractionContext context) {
        ArrayList<LearnedFrame> next = new ArrayList<>();

        for (PortalFrame frame : PortalState.visiblePortals()) {
            if (!frame.dimension().equals(context.level().dimension())) continue;

            PortalMemory.LearnedDestination destination = PortalMemory.destinationFor(frame);
            if (destination == null || destination.destinationScene() == null) continue;

            PortalMemory.SceneSnapshot scene = destination.destinationScene();
            List<PortalMemory.BlockSample> surface = selectSurfaceSamples(scene.blocks());
            ArrayList<PreparedSample> prepared = new ArrayList<>(Math.min(surface.size(), MAX_SURFACE_SAMPLES_PER_PORTAL));

            for (PortalMemory.BlockSample sample : surface) {
                if (prepared.size() >= MAX_SURFACE_SAMPLES_PER_PORTAL) break;
                if (sample.state().is(Blocks.NETHER_PORTAL) || sample.state().is(Blocks.END_PORTAL)) continue;

                BlockModelRenderState model = modelFor(sample.state());
                if (model == null) continue;
                prepared.add(new PreparedSample(
                    sample.dx(), sample.dy(), sample.dz(), sample.packedLight(), model
                ));
            }

            next.add(new LearnedFrame(
                frame,
                destination.destinationPortal(),
                scene,
                List.copyOf(prepared)
            ));
        }

        learnedFrames = List.copyOf(next);
    }

    /**
     * Keep exposed blocks first instead of taking every Nth block from scan order. The previous
     * stride sampling made stripes/holes that read visually as random pixels.
     */
    private static List<PortalMemory.BlockSample> selectSurfaceSamples(List<PortalMemory.BlockSample> blocks) {
        Set<Long> occupied = new HashSet<>(blocks.size() * 2);
        for (PortalMemory.BlockSample sample : blocks) {
            occupied.add(sampleKey(sample.dx(), sample.dy(), sample.dz()));
        }

        ArrayList<PortalMemory.BlockSample> surface = new ArrayList<>();
        for (PortalMemory.BlockSample sample : blocks) {
            int x = sample.dx();
            int y = sample.dy();
            int z = sample.dz();
            if (!occupied.contains(sampleKey(x + 1, y, z))
                || !occupied.contains(sampleKey(x - 1, y, z))
                || !occupied.contains(sampleKey(x, y + 1, z))
                || !occupied.contains(sampleKey(x, y - 1, z))
                || !occupied.contains(sampleKey(x, y, z + 1))
                || !occupied.contains(sampleKey(x, y, z - 1))) {
                surface.add(sample);
            }
        }

        // Prefer geometry close to the learned portal/arrival point when the cache is very dense.
        surface.sort(Comparator.comparingInt(PortalSurfaceRenderer::sampleDistanceSqr));
        return surface;
    }

    private static int sampleDistanceSqr(PortalMemory.BlockSample sample) {
        int x = sample.dx();
        int y = sample.dy();
        int z = sample.dz();
        return x * x + y * y + z * z;
    }

    private static long sampleKey(int x, int y, int z) {
        // Snapshot offsets stay well inside [-32, 32]. Biasing gives a compact collision-free key.
        return ((long) (x + 64) << 16) | ((long) (y + 64) << 8) | (long) (z + 64);
    }

    private static BlockModelRenderState modelFor(BlockState state) {
        BlockModelRenderState cached = MODEL_CACHE.get(state);
        if (cached != null) return cached;

        BlockStateModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
        if (model == null) return null;

        BlockModelRenderState renderState = new BlockModelRenderState();
        QuadEmitter emitter = renderState.setupMesh(
            IDENTITY_MATRIX,
            model.hasMaterialFlag(BakedQuad.FLAG_TRANSLUCENT)
        );

        model.emitQuads(
            emitter,
            BlockAndTintGetter.EMPTY,
            BlockPos.ZERO,
            state,
            renderState.scratchRandomSource(state.hashCode()),
            direction -> false
        );

        MODEL_CACHE.put(state, renderState);
        return renderState;
    }

    private static void collectSubmits(LevelRenderContext context) {
        List<LearnedFrame> frames = learnedFrames;
        if (frames.isEmpty()) return;

        Vec3 camera = context.levelState().cameraRenderState.pos;
        PoseStack poseStack = context.poseStack();

        // One far backing plane per learned opening. It only fills cache holes/sky; unlike the old
        // implementation it sits behind the full-scale scene instead of less than one block deep.
        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);
        context.submitNodeCollector().submitCustomGeometry(
            poseStack,
            RenderTypes.debugFilledBox(),
            (pose, buffer) -> {
                for (LearnedFrame learned : frames) {
                    drawFilledBox(
                        pose,
                        buffer,
                        backingBounds(learned.frame(), camera),
                        ARGB.colorFromFloat(0.97f, 0.008f, 0.008f, 0.012f)
                    );
                }
            }
        );
        poseStack.popPose();

        for (LearnedFrame learned : frames) {
            submitSnapshotModels(context, learned, camera);
        }
    }

    private static void submitSnapshotModels(LevelRenderContext context, LearnedFrame learned, Vec3 camera) {
        PortalFrame source = learned.frame();
        PortalMemory.SceneSnapshot scene = learned.scene();
        PortalFrame destination = learned.destinationPortal();
        Vec3 sourceCenter = source.center();

        double sourceBehindSign = sourceBehindSign(source, camera);
        double destinationExitSign = destinationExitSign(destination, scene.yaw());
        PoseStack poseStack = context.poseStack();

        double originBlockX = Math.floor(scene.origin().x);
        double originBlockY = Math.floor(scene.origin().y);
        double originBlockZ = Math.floor(scene.origin().z);

        for (PreparedSample sample : learned.samples()) {
            // Sample position is represented by the block center relative to the snapshot origin.
            double relX = sample.dx() + 0.5 + originBlockX - scene.origin().x;
            double relY = sample.dy() + 0.5 + originBlockY - scene.origin().y;
            double relZ = sample.dz() + 0.5 + originBlockZ - scene.origin().z;

            LocalPoint local = destinationLocal(destination, scene.yaw(), relX, relY, relZ);

            // Orient the cached destination toward the side vanilla actually dropped the player on.
            // Flipping u together with n keeps the transform non-mirrored when the exit side flips.
            double u = local.u() * destinationExitSign;
            double v = local.v();
            double n = local.n() * destinationExitSign;
            if (n < -0.35) continue;

            Vec3 targetCenter = mapBehindSource(source, sourceCenter, sourceBehindSign, u, v, n);
            if (!projectsThroughPortal(source, camera, targetCenter)) continue;

            poseStack.pushPose();
            poseStack.translate(
                targetCenter.x - camera.x - 0.5,
                targetCenter.y - camera.y - 0.5,
                targetCenter.z - camera.z - 0.5
            );
            sample.model().submit(
                poseStack,
                context.submitNodeCollector(),
                sample.packedLight(),
                OverlayTexture.NO_OVERLAY,
                0
            );
            poseStack.popPose();
        }
    }

    /** Destination coordinates expressed as portal-right / up / portal-normal. */
    private static LocalPoint destinationLocal(
        PortalFrame destination,
        float snapshotYaw,
        double relX,
        double relY,
        double relZ
    ) {
        if (destination != null) {
            return switch (destination.plane()) {
                case X -> new LocalPoint(relX, relY, relZ);
                // -Z is the local right axis for a +X-facing plane (right x up = normal).
                case Z -> new LocalPoint(-relZ, relY, relX);
                case HORIZONTAL -> new LocalPoint(relX, -relZ, -relY);
            };
        }

        // Virtual destinations (normal End entry, or a rare Nether fallback): use the player's
        // arrival yaw as the local forward axis so the cached scene opens in the direction seen on arrival.
        double yaw = Math.toRadians(snapshotYaw);
        double forwardX = -Math.sin(yaw);
        double forwardZ = Math.cos(yaw);
        double rightX = Math.cos(yaw);
        double rightZ = Math.sin(yaw);
        return new LocalPoint(
            relX * rightX + relZ * rightZ,
            relY,
            relX * forwardX + relZ * forwardZ
        );
    }

    private static double destinationExitSign(PortalFrame destination, float yawDegrees) {
        if (destination == null || destination.plane() == PortalFrame.Plane.HORIZONTAL) return 1.0;

        double yaw = Math.toRadians(yawDegrees);
        double forwardX = -Math.sin(yaw);
        double forwardZ = Math.cos(yaw);
        double normalComponent = destination.plane() == PortalFrame.Plane.X ? forwardZ : forwardX;
        return normalComponent < 0.0 ? -1.0 : 1.0;
    }

    /** Direction, in the source portal's base normal, that points away from the camera. */
    private static double sourceBehindSign(PortalFrame source, Vec3 camera) {
        Vec3 center = source.center();
        return switch (source.plane()) {
            case X -> camera.z >= center.z ? -1.0 : 1.0;
            case Z -> camera.x >= center.x ? -1.0 : 1.0;
            case HORIZONTAL -> camera.y >= center.y ? -1.0 : 1.0;
        };
    }

    /** Maps destination-local coordinates into a full-scale virtual world behind the source portal. */
    private static Vec3 mapBehindSource(
        PortalFrame source,
        Vec3 center,
        double behindSign,
        double u,
        double v,
        double n
    ) {
        double depth = PORTAL_EPSILON + Math.max(0.0, n);
        return switch (source.plane()) {
            case X -> new Vec3(
                center.x + u * behindSign,
                center.y + v,
                center.z + depth * behindSign
            );
            case Z -> new Vec3(
                center.x + depth * behindSign,
                center.y + v,
                center.z - u * behindSign
            );
            case HORIZONTAL -> new Vec3(
                center.x + u,
                center.y + depth * behindSign,
                center.z - v
            );
        };
    }

    /**
     * Cheap portal-aperture clipping. Intersect the camera -> cached-block ray with the source
     * portal plane and only submit blocks whose ray crosses the actual connected opening.
     * This prevents the cached destination from painting over the surrounding source world.
     */
    private static boolean projectsThroughPortal(PortalFrame frame, Vec3 camera, Vec3 point) {
        double t;
        double a;
        double b;
        Vec3 center = frame.center();

        switch (frame.plane()) {
            case X -> {
                double denominator = point.z - camera.z;
                if (Math.abs(denominator) < 1.0e-5) return false;
                t = (center.z - camera.z) / denominator;
                if (t <= 0.0 || t >= 1.0) return false;
                a = camera.x + (point.x - camera.x) * t;
                b = camera.y + (point.y - camera.y) * t;
                return within(a, frame.minX() + INSET - APERTURE_MARGIN, frame.maxX() + 1.0 - INSET + APERTURE_MARGIN)
                    && within(b, frame.minY() + INSET - APERTURE_MARGIN, frame.maxY() + 1.0 - INSET + APERTURE_MARGIN);
            }
            case Z -> {
                double denominator = point.x - camera.x;
                if (Math.abs(denominator) < 1.0e-5) return false;
                t = (center.x - camera.x) / denominator;
                if (t <= 0.0 || t >= 1.0) return false;
                a = camera.z + (point.z - camera.z) * t;
                b = camera.y + (point.y - camera.y) * t;
                return within(a, frame.minZ() + INSET - APERTURE_MARGIN, frame.maxZ() + 1.0 - INSET + APERTURE_MARGIN)
                    && within(b, frame.minY() + INSET - APERTURE_MARGIN, frame.maxY() + 1.0 - INSET + APERTURE_MARGIN);
            }
            case HORIZONTAL -> {
                double denominator = point.y - camera.y;
                if (Math.abs(denominator) < 1.0e-5) return false;
                t = (center.y - camera.y) / denominator;
                if (t <= 0.0 || t >= 1.0) return false;
                a = camera.x + (point.x - camera.x) * t;
                b = camera.z + (point.z - camera.z) * t;
                return within(a, frame.minX() + INSET - APERTURE_MARGIN, frame.maxX() + 1.0 - INSET + APERTURE_MARGIN)
                    && within(b, frame.minZ() + INSET - APERTURE_MARGIN, frame.maxZ() + 1.0 - INSET + APERTURE_MARGIN);
            }
        }
        return false;
    }

    private static boolean within(double value, double min, double max) {
        return value >= min && value <= max;
    }

    private static AABB backingBounds(PortalFrame frame, Vec3 camera) {
        double minX = frame.minX() + INSET;
        double minY = frame.minY() + INSET;
        double minZ = frame.minZ() + INSET;
        double maxX = frame.maxX() + 1.0 - INSET;
        double maxY = frame.maxY() + 1.0 - INSET;
        double maxZ = frame.maxZ() + 1.0 - INSET;
        Vec3 center = frame.center();

        return switch (frame.plane()) {
            case X -> {
                double direction = camera.z >= center.z ? -1.0 : 1.0;
                double z = center.z + direction * BACKING_DEPTH;
                yield new AABB(minX, minY, z - BACKING_THICKNESS, maxX, maxY, z + BACKING_THICKNESS);
            }
            case Z -> {
                double direction = camera.x >= center.x ? -1.0 : 1.0;
                double x = center.x + direction * BACKING_DEPTH;
                yield new AABB(x - BACKING_THICKNESS, minY, minZ, x + BACKING_THICKNESS, maxY, maxZ);
            }
            case HORIZONTAL -> {
                double direction = camera.y >= center.y ? -1.0 : 1.0;
                double y = center.y + direction * BACKING_DEPTH;
                yield new AABB(minX, y - BACKING_THICKNESS, minZ, maxX, y + BACKING_THICKNESS, maxZ);
            }
        };
    }

    /** Same vertex layout used by Fabric API's 26.2 rendering testmod for debugFilledBox(). */
    private static void drawFilledBox(PoseStack.Pose pose, VertexConsumer vertexConsumer, AABB box, int color) {
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.minZ).setColor(color);

        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.maxZ).setColor(color);

        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.maxZ).setColor(color);

        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.minZ).setColor(color);

        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.maxY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.maxY, (float) box.maxZ).setColor(color);

        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.maxZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.maxX, (float) box.minY, (float) box.minZ).setColor(color);
        vertexConsumer.addVertex(pose, (float) box.minX, (float) box.minY, (float) box.minZ).setColor(color);
    }
}
