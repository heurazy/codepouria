# Porting notes — Immersive Portals Client 26.2

## Objectif

Conserver uniquement l'expérience visuelle des portails Nether/End tout en gardant un contrat strictement client-only : un serveur sans ce mod doit rester compatible.

## Ce qui est repris du principe du mod original

Le rendu original traite un portail comme une ouverture à travers laquelle une autre scène est rendue, plutôt que comme une collection de carrés colorés. Son architecture complète peut rendre un autre monde en direct parce qu'elle dispose aussi de la logique serveur/chunk correspondante.

Cette réécriture garde le principe visuel « scène derrière une ouverture », mais remplace le monde distant live par une scène que le client a réellement observée auparavant.

## Workflow d'apprentissage

- Première découverte : `PortalScanner` identifie l'ouverture connectée et `PortalMemory` conserve une scène 3D du côté source dans un cache borné. Cette étape seule n’active jamais le rendu immersif.
- Approche/entrée : le snapshot source est rafraîchi au maximum une fois par seconde afin d'éviter un cache obsolète.
- Changement de dimension : vanilla/le serveur effectue la vraie téléportation.
- Arrivée : `PortalMemory` attend que la scène soit stabilisée puis capture la destination.
- Nether : si un portail vanilla d'arrivée est trouvé, les deux ouvertures sont associées et la relation inverse est créée immédiatement.
- End : l'arrivée standard n'ayant pas forcément de portail, un point de vue de destination virtuel est appris.

Les portails non appris ne reçoivent aucune surface custom.

## Rendu 26.2

Le prototype précédent compressait un volume complet dans la taille physique de l'ouverture, puis sélectionnait un bloc tous les N échantillons. Cette stratégie a été supprimée.

La passe actuelle :

- extrait les vrais `BlockStateModel` ;
- conserve en priorité les blocs exposés du snapshot ;
- réutilise le packed light enregistré dans la dimension distante ;
- reconstruit la destination à échelle 1:1 derrière le plan du portail ;
- applique une transformation locale selon l'orientation du portail source/destination ;
- teste l'intersection caméra → bloc avec le rectangle de l'ouverture pour limiter le débordement hors portail ;
- soumet le rendu via les abstractions Fabric/Minecraft 26.2 (`LevelExtractionEvents`, `LevelRenderEvents`, `BlockModelRenderState`, `SubmitNodeCollector`).

Aucun appel OpenGL brut n'est nécessaire.

## Systèmes upstream volontairement absents

- entités de portail synchronisées côté serveur ;
- chargement de chunks inter-dimension serveur ;
- tracking d'entités entre dimensions ;
- téléporteur custom côté serveur ;
- packets/handshake réseau propres au mod ;
- commandes, dimensions ou génération de portails propres au mod.

## Limites actuelles

- Le cache représente l'état observé lors de l'apprentissage : il n'est pas mis à jour à distance tant que le joueur n'y retourne pas.
- Eau/fluides et block entities nécessiteront une passe dédiée pour être aussi fidèles que les blocs statiques.
- La texture translucide vanilla du portail peut encore se superposer au cache selon l'ordre de rendu. Une passe ultérieure pourra la neutraliser uniquement pour les ouvertures apprises, sans modifier le serveur.
- Le cache n'est pas encore persisté entre deux lancements.
- Un build/test Java 25 est encore requis.
